package com.example.jagostyledemo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Pocket(val name: String, val balance: Long, val kind: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DemoApp() }
    }
}

@Composable
fun DemoApp() {
    var tab by remember { mutableStateOf(0) }
    var showBalance by remember { mutableStateOf(true) }
    var pockets by remember {
        mutableStateOf(listOf(
            Pocket("Utama", 2450000, "Transaksi"),
            Pocket("Tabungan", 1750000, "Nabung"),
            Pocket("Liburan", 850000, "Target"),
            Pocket("Belanja", 425000, "Bayar")
        ))
    }

    MaterialTheme {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    listOf("Beranda", "Kantong", "Aktivitas", "Profil").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(listOf("⌂","▣","↕","●")[i], fontSize = 20.sp) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad)) {
                when(tab) {
                    0 -> Home(pockets, showBalance, { showBalance = !showBalance }, { tab = 1 })
                    1 -> PocketScreen(pockets) { name ->
                        pockets = pockets + Pocket(name, 0, "Nabung")
                    }
                    2 -> ActivityScreen()
                    else -> ProfileScreen()
                }
            }
        }
    }
}

@Composable
fun Home(pockets: List<Pocket>, show: Boolean, toggle: () -> Unit, goPockets: () -> Unit) {
    LazyColumn(
        Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("DompetKu", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Demo aplikasi keuangan", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp)) {
                    Text("Total saldo", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        if(show) "Rp 5.475.000" else "Rp •••••••",
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Akun demo • bukan rekening bank", fontSize = 12.sp)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = toggle) { Text(if(show) "Sembunyikan" else "Tampilkan") }
                        OutlinedButton(onClick = goPockets) { Text("Kantong") }
                    }
                }
            }
        }
        item { QuickActions() }
        item { Text("Kantong kamu", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        items(pockets.take(4)) { PocketCard(it) }
        item { FeatureGrid() }
    }
}

@Composable
fun QuickActions() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Transfer", "Top Up", "QR Bayar", "Tagihan").forEach {
            OutlinedButton(onClick = {}) {
                Text(it, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun PocketCard(p: Pocket) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) { Text("●") }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold)
                Text(p.kind, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("Rp " + String.format("%,d", p.balance).replace(",", "."))
        }
    }
}

@Composable
fun FeatureGrid() {
    val features = listOf(
        "Transfer & Bayar", "Rencanakan", "Deposito",
        "Target Nabung", "Kantong Bersama", "Analisis Pengeluaran",
        "QRIS Demo", "Kartu Demo", "Bantuan"
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        features.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { f ->
                    Card(Modifier.weight(1f).height(72.dp)) {
                        Box(Modifier.fillMaxSize().padding(8.dp), contentAlignment = Alignment.Center) {
                            Text(f, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
                repeat(3-row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun PocketScreen(pockets: List<Pocket>, add: (String) -> Unit) {
    var dialog by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }

    Column(Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Kantong", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("${pockets.size} kantong demo")
            }
            Button(onClick = { dialog = true }) { Text("+ Buat") }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(pockets) { PocketCard(it) }
        }
    }

    if(dialog) {
        AlertDialog(
            onDismissRequest = { dialog = false },
            title = { Text("Buat Kantong") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama kantong") }
                )
            },
            confirmButton = {
                Button(onClick = {
                    if(name.isNotBlank()) {
                        add(name)
                        name = ""
                        dialog = false
                    }
                }) { Text("Buat") }
            },
            dismissButton = {
                TextButton(onClick = { dialog = false }) { Text("Batal") }
            }
        )
    }
}

@Composable
fun ActivityScreen() {
    val data = listOf(
        "Top Up Demo" to "+ Rp500.000",
        "Transfer Demo" to "- Rp75.000",
        "Belanja Demo" to "- Rp125.000",
        "Masuk ke Tabungan" to "+ Rp250.000",
        "Pembayaran Tagihan Demo" to "- Rp100.000"
    )
    Column(Modifier.padding(16.dp)) {
        Text("Aktivitas", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        data.forEach { (a,b) ->
            ListItem(
                headlineContent = { Text(a) },
                supportingContent = { Text("Hari ini • transaksi simulasi") },
                trailingContent = { Text(b, fontWeight = FontWeight.Bold) }
            )
            HorizontalDivider()
        }
    }
}

@Composable
fun ProfileScreen() {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Profil & Keamanan", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        listOf(
            "Data profil", "PIN & biometrik demo", "Perangkat terhubung",
            "Batas transaksi demo", "Notifikasi", "Pusat bantuan"
        ).forEach {
            Card(Modifier.fillMaxWidth()) {
                ListItem(
                    headlineContent = { Text(it) },
                    trailingContent = { Text("›", fontSize = 24.sp) }
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "PENTING: Ini prototype edukasi. Tidak terhubung ke bank, QRIS, kartu, rekening, atau uang sungguhan.",
            color = MaterialTheme.colorScheme.error,
            fontWeight = FontWeight.Bold
        )
    }
}
