# DompetKu Demo — Android Banking UI Prototype

Prototype aplikasi Android bergaya bank digital untuk pembelajaran/UI.

Fitur prototype:
- Dashboard saldo
- Kantong/budgeting
- Tambah kantong
- Menu transfer, top up, QR, dan tagihan sebagai simulasi
- Aktivitas transaksi simulasi
- Target tabungan
- Menu deposito
- Kantong bersama
- Analisis pengeluaran
- Profil dan keamanan demo

Penting: aplikasi ini tidak terhubung ke bank, QRIS, kartu, payment gateway, atau uang sungguhan.

Pengembangan lanjutan:
1. Database Room
2. Login + PIN/biometrik perangkat
3. Backend API
4. Enkripsi dan audit log
5. Integrasi payment provider resmi
6. KYC/AML, compliance, dan perizinan bila kelak menjadi layanan finansial nyata

Build:
Buka folder dengan Android Studio, Sync Project, lalu Run.
